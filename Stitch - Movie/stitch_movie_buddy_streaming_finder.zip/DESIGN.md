---
name: Obsidian Cinema
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393f'
  surface-container-lowest: '#0c0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#282a2f'
  surface-container-highest: '#33353a'
  on-surface: '#e2e2e9'
  on-surface-variant: '#d8c3ad'
  inverse-surface: '#e2e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#a08e7a'
  outline-variant: '#534434'
  surface-tint: '#ffb95f'
  primary: '#ffc174'
  on-primary: '#472a00'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#855300'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#56e5a9'
  on-tertiary: '#003824'
  tertiary-container: '#30c88f'
  on-tertiary-container: '#004e34'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#111318'
  on-background: '#e2e2e9'
  surface-variant: '#33353a'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.05em
  metric-num:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system delivers an immersive, distraction-free movie and streaming discovery experience crafted specifically for contemporary Indian audiences navigating an overwhelming multi-platform landscape. The visual direction balances the sensory intimacy of an indie screening room with the effortless speed of a native mobile tool. 

The aesthetic is anchored in **Minimalist Dark Cinema**: vast, pitch-black negative space punctuated by high-fidelity key art, razor-sharp micro-borders, and tactile neon accent tones. It rejects visual clutter, dense dashboard grids, and noisy ad surfaces. Every interaction feels deliberate, ambient, and curated—transforming the chore of searching through fragmented catalogs into an intuitive, vibe-first evening ritual.

## Colors

The palette simulates the environment of a darkened theater, allowing dynamic content art and mood indicators to command full attention while maintaining strict hierarchy.

### Core Canvas & Surfaces
- **Canvas Base:** `#0B0D12` forms the default background abyss.
- **Sub-canvas / Navigation:** `#0E121A` provides grounding for floating bars and header wells.
- **Card Surfaces:** `#141821` (resting surface) steps up to `#1A1F2C` on interactive or hovered states.
- **Structural Dividers:** `#232938` creates razor-thin boundaries with minimal ambient distraction.

### Text Hierarchy
- **Primary Text:** `#F3F4F6` for crisp legibility across headlines, titles, and critical metadata.
- **Secondary Text:** `#9CA3AF` for runtimes, director credits, release years, and narrative synopsis.
- **Sub-muted Text:** `#64748B` for inactive icons, structural labels, timestamps, and legal metadata.

### Accent Accompanying & Metrics
- **Primary Accent (Warm Amber):** `#F59E0B` (hover: `#D97706`) evokes marquee glow and editorial recommendations.
- **Secondary Accent (Vibrant Indigo):** `#6366F1` highlights vibe categories and mood filters.
- **Tertiary Accent (Emerald Green):** `#10B981` denotes algorithmic match ratings and high sentiment scores.

### OTT & Regional Platform Accents
Used strictly within platform badges, availability tags, and direct watch links:
- **Prime Video:** `#00A8E1`
- **Netflix:** `#E50914`
- **Disney+ Hotstar / JioCinema:** `#00ED82`
- **YouTube:** `#FF0000`
- **Zee5 / SonyLIV:** `#8B5CF6`

## Typography

The typography scale utilizes **Plus Jakarta Sans** uniformly across all displays to preserve architectural purity and sleek modernism. 

- **Display & Headings:** Employs condensed letter-spacing (`-0.03em` to `-0.015em`) with heavier weights (`600` to `800`) to evoke cinematic titles without visual bloat.
- **Body:** Open line heights (`1.5` ratio) counteract eye fatigue on pitch-black screens.
- **Metadata & Figures:** Runtimes, release years, language badges, and match percentages must utilize standard tabular figures (`font-variant-numeric: tabular-nums`) to ensure vertical alignment across streaming lists.

## Layout & Spacing

The layout embraces a mobile-first philosophy that translates into a focused, distraction-free reading column on desktop.

- **Desktop Shell:** Constrained to a centered `max-width: 880px` canvas container, guaranteeing that widescreen viewports mirror the rapid scanning speed of a handheld device rather than spreading cards horizontally across excessive whitespace.
- **Mobile Foundation:** Fluid layout bounded by `16px` (`1rem`) horizontal padding, maximizing screen estate for horizontal poster scrollers and stackable category tags.
- **Grid Architecture:** 
  - Mobile: Single-column vertical stream or 2-column poster grid with `12px` (`0.75rem`) gutters.
  - Desktop: 12-column internal grid with `16px` (`1rem`) gutters, allowing clean `4-col` (3 cards per row) or `6-col` (split view) breakdowns.
- **Rhythm:** Spacing follows an absolute 4px base unit. Internal component spacing heavily favors tight clusters (`space-xs` and `space-sm`) surrounded by generous section margins (`space-xl` and `space-2xl`).

## Elevation & Depth

Visual hierarchy is maintained strictly through **Tonal Layers** and **Low-Contrast Outlines**, avoiding murky drop shadows that muddy deep OLED blacks.

- **Surface Levels:**
  - *Floor (Level 0):* Deep obsidian canvas (`#0B0D12`).
  - *Sub-layer (Level 1):* Recessed carousels and bottom navigation bars (`#0E121A`).
  - *Resting Surfaces (Level 2):* Standard cards, sheets, and modular panels (`#141821`) bordered by a continuous 1px `#232938` boundary.
  - *Interactive / Floating (Level 3):* Modals, active states, and expanded filters (`#1A1F2C`) framed by a brighter edge highlight (`#333B4F`).
- **Ambient Lighting:** Shadows are restricted exclusively to floating bottom actions and sticky headers: `0 8px 32px rgba(0, 0, 0, 0.75)`. When accent cards are highlighted (such as an ultra-high 98% Match), an ambient rim glow (`0 0 20px rgba(16, 185, 129, 0.15)`) creates an ethereal, backlit theater-screen effect.

## Shapes

The system relies on structured geometry softened by uniform curvature, balancing structural density with modern fluidity.

- **Cards & Modals:** Standard curvature of `0.5rem` (`8px`) on containers and poster wrappers prevents harsh rectangular edges without turning into bulbous forms.
- **Pills & Selectors:** Dynamic filters, mood tokens, platform identifiers, and quick-add buttons use pure full-radius pill styling (`9999px`).
- **Indian Film Certification Badges:** Strict, punchy squares with micro-rounded corners (`4px` / `rounded-sm`) to replicate authentic CBFC theatrical censor board slates.

## Components

### Buttons
- **Primary Action (Play / Watch Options):** Background `#F59E0B`, text `#0B0D12`, font weight 700. Pressed state transitions to `#D97706`. Height `44px` on mobile for accessible touch targets.
- **Secondary Action (Add to Watchlist):** Solid surface `#1A1F2C` with 1px border `#232938`, text `#F3F4F6`. Hover triggers border `#333B4F` with subtle background lift.
- **Tertiary / Ghost (Share, More Info):** Transparent surface with muted slate text `#9CA3AF`, shifting to crisp `#F3F4F6` on interaction.

### Vibe & Filter Chips (Pills)
- **Inactive:** `#141821` fill, 1px border `#232938`, text `#9CA3AF`.
- **Active / Selected:** Indigo wash `#6366F1` background with white `#FFFFFF` text and no border, providing instant visual feedback across horizontal mood carousels (e.g., *Late Night Mind-Benders*, *Monsoon Melancholy*, *Heartland Gritty*).

### Media Cards
- **Poster Ratio:** Standard 2:3 vertical proportion. Posters feature an inner 1px inset highlight (`inset 0 0 0 1px rgba(255, 255, 255, 0.05)`) over the image edge.
- **Card Body:** Background `#141821`, 1px border `#232938`. Contains title, runtime, language tags (Hindi, Tamil, Malayalam, Telugu, English), and streaming provider icons nestled at the bottom right.

### Badges & Metrics
- **CBFC Certification Badges:** High-contrast tags (`U`, `UA`, `A`, `S`) formatted in a crisp 20x20px square with a 1px border `#64748B`, text `#F3F4F6`, uppercase, tracking `0.05em`.
- **Match Score:** Pill badge featuring tertiary emerald `#10B981` at 10% opacity, border `rgba(16, 185, 129, 0.3)`, text `#10B981` accompanied by a localized spark icon.
- **Streaming Platforms:** Compact horizontal chips containing the native streaming service emblem next to stream availability ("Included", "Rent", or "Free").

### Input Fields & Search
- Surface `#0E121A`, inset 1px border `#232938`, text `#F3F4F6`, placeholder `#64748B`.
- Focused state eliminates generic browser rings in favor of a crisp `1px border #F59E0B` with zero shadow spread to preserve cinematic minimalism.

### Selection Controls (Checkboxes & Radios)
- Base `#141821` with 1.5px border `#232938`.
- Checked state fills with `#F59E0B` carrying an obsidian checkmark or bullet `#0B0D12`.